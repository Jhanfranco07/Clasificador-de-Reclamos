# SmartClaim AI — Datos completos de la entrega final
Paquete de datasets académicos originales y archivos derivados, con datos verificables del repositorio.

## Cantidades
- **105 reclamos** etiquetados en **7 categorías** en `01_Clasificacion_ML/reclamos_entrenamiento.csv`.
- **60 documentos RAG** en `02_Base_Documental/documentos_RAG_60_completos.json` y `.csv`: 18 procedentes de la semilla PostgreSQL y 42 del catálogo académico adicional.
- **60 consultas de evaluación RAG**, incluidas 4 sin documentación esperada.
- Un reporte de entrenamiento real generado durante el desarrollo.

## Archivos
- `01_Clasificacion_ML/reclamos_entrenamiento.csv`: todos los textos y etiquetas de clasificación.
- `01_Clasificacion_ML/training_report.txt`: resultado del entrenamiento registrado en el repositorio.
- `02_Base_Documental/documentos_RAG_60_completos.json`: los 60 documentos reunidos con sus fuentes.
- `02_Base_Documental/documentos_RAG_60_completos.csv`: contenido equivalente listo para abrir en Excel.
- `02_Base_Documental/documentos_academicos.json`: los 42 documentos originales adicionales y metadatos.
- `03_Evaluacion_RAG/consultas_rag.json`: 60 casos de consulta y sus documentos esperados.
- `04_SQL_Datos_Referenciales/postgres_seed_data.sql`: semilla con los 18 documentos base, categorías y datos ficticios.
- `04_SQL_Datos_Referenciales/postgres_schema.sql`: esquema PostgreSQL reproducible.
- `05_Documentacion/DICCIONARIO_DATOS.md`: explicación de las tablas.
- `MANIFIESTO.json`: procedencia y conteos.

## Cómo se generó el archivo consolidado de 60 documentos
Los 18 documentos base se extrajeron de la sentencia `INSERT INTO documentos_base` de `postgres_seed_data.sql`, preservando contenido, título, categoría y tipo. Los otros 42 se tomaron íntegramente de `documentos_academicos.json`. El `id_semilla` aplica solo a las 18 entradas originales; los IDs reales de producción de los 42 adicionales pueden variar. **El catálogo consolidado es una copia académica reproducible, no una exportación de Supabase en vivo.**

## Entrenamiento y evaluación
El script original `scripts/train_model.py` (en el repositorio) usa un reparto estratificado del 25 % para validación (`random_state=42`), junto con TF-IDF y regresión logística. Los 105 ejemplos originales están completos y no se modificaron.
`scripts/evaluate_rag.py` evalúa las 60 consultas sobre una base SQLite temporal con el catálogo y semillas.

## Seguridad
No contiene `.env`, secretos, credenciales de Supabase ni datos privados de clientes de producción. Los archivos SQL son materiales académicos del repositorio. No ejecutar semillas sobre producción sin revisión.

Repositorio fuente: https://github.com/Jhanfranco07/Clasificador-de-Reclamos
